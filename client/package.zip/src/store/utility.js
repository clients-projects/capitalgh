const update = (state, action) => {
    return {
        ...state,
        ...action
    }
}

export default update;

